#include <xmc_common.h>

void initCCU4(void);
void connectLED(void);

int main(void) {
  
  initCCU4();

  while(1);
  return 0;
}

void initCCU4() {
}

void connectLED() {
}

